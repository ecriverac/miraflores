$(document).ready(function(e) {
  window.onresize=function(){
		$("body").height(window.innerHeight);
	}
	window.onresize();
});