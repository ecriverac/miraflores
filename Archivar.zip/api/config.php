<?php 
	$rutaData_nivel3="../../../data";
?>